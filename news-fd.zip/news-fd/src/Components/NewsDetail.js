import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const modernStyles = {
  container: {
    fontFamily: "'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
    padding: "40px 20px",
    maxWidth: "900px", 
    margin: "0 auto", 
    backgroundColor: "#ffffff",
    borderRadius: "12px",
    boxShadow: "0 6px 20px rgba(0, 0, 0, 0.08)",
    overflow: "hidden", 
    minHeight: "50vh", 
    display: "flex",
    flexDirection: "column", 
    justifyContent: "space-between", 
    boxSizing: "border-box", 
  },
backButton: {
  display: "inline-flex",           
  alignItems: "center",
  marginBottom: "20px",
  padding: "10px 20px",               
  backgroundColor: "#007bff",
  color: "white",
  textDecoration: "none",
  borderRadius: "5px",
  fontSize: "1em",               
  fontWeight: "500",
  cursor: "pointer",
  border: "none",
  transition: "background-color 0.3s ease, transform 0.2s ease",
  gap: "4px",
  flexShrink: 0,
  width: "fit-content",            
},

  backButtonHover: {
    backgroundColor: "#0056b3",
    transform: "translateY(-2px)",
  },
  image: {
    width: "100%",
    maxHeight: "30vh", 
    objectFit: "contain", 
    borderRadius: "10px",
    marginBottom: "20px", 
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
    flexShrink: 0, 
  },
  title: {
    fontSize: "2.2em", 
    fontWeight: "700",
    color: "#212529",
    marginBottom: "10px", 
    lineHeight: "1.2",
    flexShrink: 0, 
  },
  meta: {
    display: "flex",
    flexWrap: "wrap",
    gap: "10px 20px", 
    fontSize: "0.85em", 
    color: "#6c757d",
    marginBottom: "20px", 
    paddingBottom: "15px",
    borderBottom: "1px solid #e9ecef",
    flexShrink: 0, 
  },
  metaItem: {
    display: "flex",
    alignItems: "center",
    gap: "5px",
  },
  contentArea: {
    flexGrow: 1, 
    overflow: "hidden", 
    fontSize: "1em", 
    lineHeight: "1.6",
    color: "#343a40",
    whiteSpace: "pre-wrap",
    paddingBottom: "15px", 
    display: "flex", 
    flexDirection: "column",
    justifyContent: "space-between", 
  },
  articleContentText: {

  },
  readMoreLink: {
    display: "inline-block",
    marginTop: "15px", 
    padding: "10px 20px", 
    backgroundColor: "#28a745",
    color: "white",
    textDecoration: "none",
    borderRadius: "8px",
    fontWeight: "600",
    transition: "background-color 0.3s ease, transform 0.2s ease",
    alignSelf: "flex-start", 
    flexShrink: 0, 
  },
  readMoreLinkHover: {
    backgroundColor: "#218838",
    transform: "translateY(-2px)",
  },
  icon: {
    marginRight: "5px",
    color: "#007bff",
  },
};

function NewsDetail() {
  const location = useLocation();
  const navigate = useNavigate();
  const { article } = location.state || {};

  const [isHovered, setIsHovered] = useState(false);
  const [isLinkHovered, setIsLinkHovered] = useState(false);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden"; 

    return () => {
      document.body.style.overflow = "";
      document.documentElement.style.overflow = "";
    };
  }, []);

  if (!article) {
    return (
      <div style={modernStyles.container}>
        <p>No news article found. Please go back to the news list.</p>
        <button
          onClick={() => navigate("/")}
          style={{
            ...modernStyles.backButton,
            ...(isHovered ? modernStyles.backButtonHover : {}),
          }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          &larr; Go Back
        </button>
      </div>
    );
  }

  return (
    <div style={modernStyles.container}>
      <button
        onClick={() => navigate("/")}
        style={{
          ...modernStyles.backButton,
          ...(isHovered ? modernStyles.backButtonHover : {}),
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <span style={modernStyles.icon}>&#x2190;</span> Back to News
      </button>

      {article.urlToImage && (
        <img
          src={article.urlToImage}
          alt={article.title}
          style={modernStyles.image}
        />
      )}

      <h1 style={modernStyles.title}>{article.title}</h1>

      <div style={modernStyles.meta}>
        <p style={modernStyles.metaItem}>
          <span style={modernStyles.icon}>&#128100;</span>
          <strong>Author:</strong> {article.author || "Unknown Author"}
        </p>
        <p style={modernStyles.metaItem}>
          <span style={modernStyles.icon}>&#128197;</span>
          <strong>Published:</strong>{" "}
          {new Date(article.publishedAt).toLocaleString()}
        </p>
        <p style={modernStyles.metaItem}>
          <span style={modernStyles.icon}>&#128200;</span>
          <strong>Source:</strong> {article.source?.name || "Unknown Source"}
        </p>
      </div>

      <div style={modernStyles.contentArea}>
        <p style={modernStyles.articleContentText}>
          {article.content}
        </p>
        {article.url && (
          <p>
            <a
              href={article.url}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                ...modernStyles.readMoreLink,
                ...(isLinkHovered ? modernStyles.readMoreLinkHover : {}),
              }}
              onMouseEnter={() => setIsLinkHovered(true)}
              onMouseLeave={() => setIsLinkHovered(false)}
            >
              Read the full article on the original site{" "}
              <span style={{ fontSize: "0.8em" }}>&#x2192;</span>
            </a>
          </p>
        )}
      </div>
    </div>
  );
}

export default NewsDetail;